package project1b.ver03;

public class NormalAccount extends Account{
	
	NormalAccount(String accountNum, String name, int balance, int rate) {
		super(accountNum,name,balance,rate);
	}


	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return super.getName();
	}

	@Override
	public int getBalance() {
		// TODO Auto-generated method stub
		return super.getBalance();
	}


	@Override
	public int getRate() {
		// TODO Auto-generated method stub
		return super.getRate();
	}


	@Override
	public String getAccountNum() {
		// TODO Auto-generated method stub
		return super.getAccountNum();
	}

	
	
	
}
