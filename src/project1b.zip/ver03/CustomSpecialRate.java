package project1b.ver03;

public interface CustomSpecialRate {
 
	int A=7, B = 4, C = 2;

}
