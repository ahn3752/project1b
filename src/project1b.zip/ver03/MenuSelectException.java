package project1b.ver03;

public class MenuSelectException extends Exception {
	   
	   public MenuSelectException() {
	      super();
	   }

	   public MenuSelectException(String message) {
	      super(message);
	      }
	}
