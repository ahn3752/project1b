package project1b.ver02;

public interface CustomSpecialRate {
 
	int A=7, B = 4, C = 2;

}
