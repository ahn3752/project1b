package project1b;

import project1b.ver02.AccountManager;

public class BankingSystemVer02 {

	public static void main(String[] args) {
		
		AccountManager accountmanager = new AccountManager();
		
		accountmanager.showMenu();

	}

}
