package project1b.ver04;

public interface MenuChoice {
	 int MAKE = 1,DEPOSIT = 2,WITHDRAW = 3,INQUIRE = 4, SAVE= 5, GAME=6, EXIT = 7;
	
}
