package project1b.ver04;

public class MenuSelectException extends Exception {
	   
	   public MenuSelectException() {
	      super();
	   }

	   public MenuSelectException(String message) {
	      super(message);
	      }
	}
